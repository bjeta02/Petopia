import React, { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import { Dialog } from "primereact/dialog";
import axios from "axios";
import "./Appointments.css";

const Appointments = () => {
    const [appointments, setAppointments] = useState([]);
    const [selectedAppointment, setSelectedAppointment] = useState(null);
    const [editDialog, setEditDialog] = useState(false);
    const toast = React.useRef(null);

    useEffect(() => {
        fetchAppointments();
    }, []);

    // Fetch appointments from the backend
    const fetchAppointments = async () => {
        try {
            const response = await axios.get("http://localhost:5001/api/appointments");
            setAppointments(response.data);
        } catch (error) {
            console.error("Error fetching appointments:", error);
        }
    };

    // Show toast message
    const showToast = (severity, summary, detail) => {
        toast.current.show({ severity, summary, detail, life: 3000 });
    };

    // Handle delete appointment
    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:5000/api/appointments/${id}`);
            showToast("success", "Deleted", "Appointment successfully deleted.");
            fetchAppointments(); // Refresh data
        } catch (error) {
            showToast("error", "Error", "Failed to delete appointment.");
        }
    };

    // Handle edit button click (open dialog)
    const handleEdit = (appointment) => {
        setSelectedAppointment(appointment);
        setEditDialog(true);
    };

    // Handle updating the appointment
    const handleUpdate = async () => {
        try {
            await axios.put(`http://localhost:5001/api/appointments/${selectedAppointment._id}`, selectedAppointment);
            showToast("success", "Updated", "Appointment updated successfully.");
            setEditDialog(false);
            fetchAppointments();
        } catch (error) {
            showToast("error", "Error", "Failed to update appointment.");
        }
    };

    // Format status with styles
    const formatStatus = (rowData) => {
        return <span className={`status-tag ${rowData.status.toLowerCase()}`}>{rowData.status}</span>;
    };

    // Display action buttons (Edit & Delete)
    const actionTemplate = (rowData) => {
        return (
            <div className="action-buttons">
                <Button icon="pi pi-pencil" className="edit-btn" onClick={() => handleEdit(rowData)} />
                <Button icon="pi pi-trash" className="delete-btn" onClick={() => handleDelete(rowData._id)} />
            </div>
        );
    };

    return (
        <div className="appointments-container">
            <Toast ref={toast} position="bottom-right" />

            <div className="toolbar">
                <Button label="Export" icon="pi pi-file" className="export-btn" />
            </div>

            <DataTable value={appointments} className="datatable" paginator rows={5}>
                <Column field="owner_id.first_name" header="Pet Owner" />
                <Column field="pet_id.name" header="Pet Name" />
                <Column field="pet_id.type" header="Pet Type" />
                <Column field="service_needed" header="Service Needed" />
                <Column field="date" header="Date" />
                <Column field="status" header="Status" body={formatStatus} />
                <Column header="Actions" body={actionTemplate} />
            </DataTable>

            {/* Edit Dialog */}
            <Dialog visible={editDialog} header="Edit Appointment" onHide={() => setEditDialog(false)}>
                {selectedAppointment && (
                    <div className="p-field">
                        <label>Status</label>
                        <select
                            className="p-inputtext"
                            value={selectedAppointment.status}
                            onChange={(e) =>
                                setSelectedAppointment({ ...selectedAppointment, status: e.target.value })
                            }
                        >
                            <option value="Pending">Pending</option>
                            <option value="Scheduled">Scheduled</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                )}
                <div className="p-dialog-footer">
                    <Button label="Cancel" className="p-button-secondary" onClick={() => setEditDialog(false)} />
                    <Button label="Update" className="p-button-primary" onClick={handleUpdate} />
                </div>
            </Dialog>
        </div>
    );
};

export default Appointments;
