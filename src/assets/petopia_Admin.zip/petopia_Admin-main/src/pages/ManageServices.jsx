import React, { useState } from "react";
import styled from "styled-components";

const Container = styled.div`
 
`;

const SchedulerContainer = styled.div`
  background-color: #fff;
  padding: 10px;
  width: 100%;  
  max-width: 1200px;
  margin-top: -30px
`;

const Header = styled.h2`
  text-align: start;
  color: #333;
`;

const ScheduleGrid = styled.div`
  display: grid;
  grid-template-columns: 135px repeat(7, 1fr); /* Ensure first column is 150px */
  margin-top: 20px;
  gap: 0px; /* Remove any unintended spacing */
`;

const TimeSlot = styled.div`
  background-color: ${(props) => props.color || "#fff"};
  padding: 10px;
  text-align: center;
  color: #000;
  font-size: 10px;
  border: 1px solid #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  grid-row: span ${(props) => props.rowSpan || 1}; /* Merge consecutive slots */
`;

const TimeColumn = styled.div`
  text-align: center;
  padding: 10px;
  background-color: #eee;
  border: 1px solid #ccc;
  font-size: 10px;
  width: 135px; /* Match the first column width */
`;

const categories = {
  Consultation: "#007bff",
  Surgery: "#dc3545",
  Checkup: "#28a745",
};

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const hours = [
  "7:30 AM - 8:00 AM", "8:00 AM - 8:30 AM", "8:30 AM - 9:00 AM", "9:00 AM - 9:30 AM", "9:30 AM - 10:00 AM", 
  "10:00 AM - 10:30 AM", "10:30 AM - 11:00 AM", "11:00 AM - 11:30 AM", "11:30 AM - 12:00 PM", "12:00 PM - 12:30 PM", 
  "12:30 PM - 1:00 PM", "1:00 PM - 1:30 PM", "1:30 PM - 2:00 PM", "2:00 PM - 2:30 PM", "2:30 PM - 3:00 PM", 
  "3:00 PM - 3:30 PM", "3:30 PM - 4:00 PM", "4:00 PM - 4:30 PM", "4:30 PM - 5:00 PM", "5:00 PM - 5:30 PM", 
  "5:30 PM - 6:00 PM", "6:00 PM - 6:30 PM", "6:30 PM - 7:00 PM", "7:00 PM - 7:30 PM"
];

const DoctorScheduler = () => {
  const [appointments, setAppointments] = useState([
    { day: "Monday", startTime: "10:00 AM", endTime: "1:00 PM", text: "John Doe - Consultation", category: "Consultation" },
    { day: "Wednesday", startTime: "11:00 AM", endTime: "12:00 PM", text: "Jane Smith - Surgery", category: "Surgery" },
    { day: "Friday", startTime: "2:00 PM", endTime: "3:30 PM", text: "Mark Lee - Checkup", category: "Checkup" },
  ]);

  return (
    <Container>
      <SchedulerContainer>
        <Header>Doctor Appointment Scheduler</Header>
        
        <ScheduleGrid>
          <TimeColumn> Time </TimeColumn>
          {daysOfWeek.map((day) => (
            <TimeColumn key={day}>{day}</TimeColumn>
          ))}
          {hours.map((hour, index) => (
            <>
              <TimeColumn key={hour}>{hour}</TimeColumn>
              {daysOfWeek.map((day) => {
                const appointment = appointments.find(
                  (appt) => appt.day === day && appt.startTime === hour.split(" - ")[0]
                );

                if (appointment) {
                  const startIdx = hours.findIndex((h) => h.startsWith(appointment.startTime));
                  const endIdx = hours.findIndex((h) => h.startsWith(appointment.endTime));
                  const rowSpan = endIdx - startIdx; // Number of slots to merge

                  return (
                    <TimeSlot key={`${day}-${hour}`} color={categories[appointment.category]} rowSpan={rowSpan}>
                      {appointment.text}
                    </TimeSlot>
                  );
                }

                return index > 0 && appointments.some(
                  (appt) => appt.day === day && appt.startTime <= hour.split(" - ")[0] && appt.endTime > hour.split(" - ")[0]
                ) ? null : (
                  <TimeSlot key={`${day}-${hour}`} />
                );
              })}
            </>
          ))}
        </ScheduleGrid>
      </SchedulerContainer>
    </Container>
  );
};

export default DoctorScheduler;
