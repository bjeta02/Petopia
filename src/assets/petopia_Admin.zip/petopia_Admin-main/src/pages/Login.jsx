import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Message } from 'primereact/message';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import './Login.css'; // Add your custom styles here
import logo from '../assets/logo.jpg'; // Replace with your logo path

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isPasswordVisible, setIsPasswordVisible] = useState(false); // Track visibility
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const validCredentials = {
        email: "test@example.com",
        password: "password123"
    };

    const validateForm = () => {
        const newErrors = {};
        if (!email) newErrors.email = 'Email is required';
        else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Invalid email format';
        
        if (!password) newErrors.password = 'Password is required';
        else if (password.length < 6) newErrors.password = 'Password must be at least 6 characters';
        
        return newErrors;
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        setErrors({});
        setLoading(true);

        const formErrors = validateForm();
        if (Object.keys(formErrors).length > 0) {
            setErrors(formErrors);
            setLoading(false);
            return;
        }

        // Simulate API Call
        setTimeout(() => {
            if (email === validCredentials.email && password === validCredentials.password) {
                navigate('/home'); // Redirect on success
            } else {
                setErrors({ login: 'Incorrect email or password' });
            }
            setLoading(false);
        }, 1000);
    };

    const togglePasswordVisibility = () => {
        setIsPasswordVisible(!isPasswordVisible); // Toggle the visibility of the password
    };

    return (
        <div className="flex justify-content-center align-items-center h-screen bg-blue-50">
            <Card className="shadow-5 p-6 w-full sm:w-10 md:w-6 lg:w-4">
                {/* Logo Section */}
                <div className="flex justify-content-center mb-4" style={{marginTop: '-30px'}}>
                    <img src={logo} alt="Logo" style={{ width: '200px', height: 'auto' }} />
                </div>

                {errors.login && <Message severity="error mb-3" text={errors.login} />}

                <form onSubmit={handleSubmit} className="flex flex-column gap-4">
                    <div>
                        <label htmlFor="email" className="block text-900 font-medium mb-1">Email</label>
                        <span className="p-input-icon-left w-full">
                            <i className="pi pi-envelope" style={{marginLeft: '10px'}} />
                            <InputText 
                                id="email"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={`w-full ${errors.email ? 'p-invalid' : ''}`}
                                placeholder="Enter your email"
                                style={{textIndent: '23px'}}
                            />
                        </span>
                        {errors.email && <small className="p-error mb-2">{errors.email}</small>}
                    </div>

                    <div>
                        <label htmlFor="password" className="block text-900 font-medium mb-1">Password</label>
                        <div className="p-input-icon-left w-full mb-2" style={{ position: 'relative' }}>
                            <i className="pi pi-lock" style={{ marginLeft: '10px' }} />
                            <InputText
                                id="password"
                                type={isPasswordVisible ? "text" : "password"} // Toggle between text and password
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className={`w-full ${errors.password ? 'p-invalid' : ''}`}
                                placeholder="Enter your password"
                                style={{ textIndent: '23px' }}
                            />
                            <i
                                className={`pi ${isPasswordVisible ? 'pi-eye' : 'pi-eye-slash'}`}
                                style={{ position: 'absolute', right: '10px', top: '70%', transform: 'translateY(-50%)', cursor: 'pointer' }}
                                onClick={togglePasswordVisibility}
                            />
                        </div>
                        {errors.password && <small className="p-error mb-2">{errors.password}</small>}
                    </div>

                    <div className="flex justify-content-end" style={{marginTop: '-24px'}}>
                        <a href="/forgot-password" className="text-gray-600 hover:text-gray-800 no-underline transition duration-200 ease-in-out" style={{ fontSize: '13px'}}>
                            Forgot Password?
                        </a>
                    </div>

                    <Button 
                        type="Submit"
                        label="Login"
                        className="w-full"
                        loading={loading}
                        style={{
                            background: '#4ea87e',
                            border: 'none',
                            boxShadow: 'none'
                        }}
                    />

                    <div className="flex justify-content-center">
                        <span className="text-gray-600 hover:text-gray-800 font-semibold italic no-underline transition duration-200 ease-in-out">
                            Not registered yet? 
                        </span>
                        <a 
                            href="/signup" 
                            className="font-semibold italic no-underline transition duration-200 ease-in-out cursor-pointer ml-1"
                            style={{ color: '#4ea87e' }}
                        >
                            Register
                        </a>
                    </div>
                </form>
            </Card>
        </div>
    );
};

export default Login;
