import React, { useState } from 'react';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Button } from 'primereact/button';
import { Message } from 'primereact/message';
import { useNavigate } from 'react-router-dom';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import './Signup.css';
import logo from '../assets/logo.jpg'; 
import arrow from '../assets/arrow.png';

const Signup = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [mobile, setMobile] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const validateForm = () => {
        const newErrors = {};
        if (!firstName) newErrors.firstName = 'First Name is required';
        if (!lastName) newErrors.lastName = 'Last Name is required';
        if (!mobile) newErrors.mobile = 'Mobile Phone Number is required';
        if (!email) newErrors.email = 'Email is required';
        else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Invalid email format';
        if (!password) newErrors.password = 'Password is required';
        if (password !== confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
        
        return newErrors;
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        setErrors({});
        setLoading(true);

        const formErrors = validateForm();
        if (Object.keys(formErrors).length > 0) {
            setErrors(formErrors);
            setLoading(false);
            return;
        }

        // Simulate API Call for Signup
        setTimeout(() => {
            // Handle the signup logic
            console.log('User Registered:', { firstName, lastName, mobile, email, password });
            navigate('/login'); // Redirect to login page after successful signup
            setLoading(false);
        }, 1000);
    };

    return (
        <div className="flex justify-content-center align-items-center h-screen">
            <div style={{ 
                    width: '700px', 
                    backgroundColor: 'white', 
                    height: '100%', 
                    padding: '20px'
                }}>
                    {/* Logo Section */}
                    <div style={{
                        display: 'flex',          
                        justifyContent: 'center',  
                        alignItems: 'center',
                        marginTop: '20%'
                    }}>
                        <img src={logo} alt="Logo" style={{ width: '250px', height: 'auto' }} />
                    </div>

                    {/* Title Section */}
                    <div style={{
                        justifyContent: 'center',  // Center horizontally
                        alignItems: 'center',
                        marginLeft: '90px',
                        marginRight: '50px',
                        marginTop: '50px',
                        fontSize: '25px',   
                        fontWeight: 'bold',
                        color: '#095d7e'
                    }}>
                        The #1 management app for your pet's needs
                    </div>

                    {/* Checkmark List */}
                    <ul style={{ 
                        listStyle: 'none', 
                        padding: 0, 
                        marginTop: '30px', 
                        fontSize: '18px',
                        marginLeft: '90px',
                        color: '#4A4A4A' 
                    }}>
                        {[
                            'Veterinary Checkups',
                            'Pet Vaccinations',
                            'Grooming & Spa',
                            'Pet Food & Supplies'
                        ].map((item, index) => (
                            <li key={index} style={{ 
                                display: 'flex', 
                                alignItems: 'center', 
                                marginBottom: '10px' 
                            }}>
                                <span style={{ 
                                    color: '#00A86B', 
                                    fontSize: '20px', 
                                    marginRight: '10px' 
                                }}>✔</span>
                                {item}
                            </li>
                        ))}
                    </ul>
                </div>

            <div style={{
                position: 'absolute',
                top: '50%',
                left: '33%',
                transform: 'translate(-50%, -50%)',
                zIndex: 10
            }}>
                <img src={arrow} alt="Arrow" style={{ width: '200px', height: 'auto' }} />
            </div>
            
            <div style={{backgroundColor: '#f1f8ff', padding: '9rem' }}>
                
                    <h1 style={{marginTop: '350px', fontSize: '50px', color: '#095d7e'}}>Get started for free!</h1>

                    <p className="mb-4 text-gray-700" style={{fontSize: '22px'}}>To get started, fill out the form below. It only takes 5 minutes to set up your digital practice and profile.</p>

                    {Object.keys(errors).length > 0 && 
                        <Message severity="error" text="Please fill in all the required fields correctly" className="mb-3" />
                    }

                    <form onSubmit={handleSubmit} className="flex flex-column gap-4">
                        <div className="flex gap-4">
                            {/* First Name Field */}
                            <div className="w-full sm:w-1/2">
                                <label htmlFor="firstName" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>First Name</label>
                                <InputText
                                    id="firstName"
                                    value={firstName}
                                    onChange={(e) => setFirstName(e.target.value)}
                                    className={`w-full ${errors.firstName ? 'p-invalid' : ''} p-inputtext-lg`}
                                    placeholder="Enter your first name"
                                />
                                {errors.firstName && <small className="p-error mb-2">{errors.firstName}</small>}
                            </div>

                            {/* Last Name Field */}
                            <div className="w-full sm:w-1/2">
                                <label htmlFor="lastName" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>Last Name</label>
                                <InputText
                                    id="lastName"
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                    className={`w-full ${errors.lastName ? 'p-invalid' : ''} p-inputtext-lg`}
                                    placeholder="Enter your last name"
                                />
                                {errors.lastName && <small className="p-error mb-2 ">{errors.lastName}</small>}
                            </div>
                        </div>

                        <div>
                            <label htmlFor="mobile" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>Mobile Phone Number</label>
                            <InputText
                                id="mobile"
                                value={mobile}
                                onChange={(e) => setMobile(e.target.value)}
                                className={`w-full ${errors.mobile ? 'p-invalid' : ''} p-inputtext-lg`}
                                placeholder="Enter your mobile phone number"
                            />
                            {errors.mobile && <small className="p-error mb-2">{errors.mobile}</small>}
                        </div>

                        <div>
                            <label htmlFor="email" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>Email Address</label>
                            <InputText
                                id="email"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={`w-full ${errors.email ? 'p-invalid' : ''} p-inputtext-lg`}
                                placeholder="Enter your email"
                            />
                            {errors.email && <small className="p-error mb-2">{errors.email}</small>}
                        </div>

                        <div>
                            <label htmlFor="password" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>Password</label>
                            <InputText
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className={`w-full ${errors.password ? 'p-invalid' : ''} p-inputtext-lg`}
                                placeholder="Enter your password"
                                toggleMask
                            />
                            {errors.password && <small className="p-error mb-2">{errors.password}</small>}
                        </div>

                        <div>
                            <label htmlFor="confirmPassword" className="block text-900 font-medium mb-3 mt-2" style={{fontSize: '18px'}}>Confirm Password</label>
                            <InputText
                                id="confirmPassword"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                className={`w-full ${errors.confirmPassword ? 'p-invalid' : ''} p-inputtext-lg `}
                                placeholder="Confirm your password"
                                toggleMask
                            />
                            {errors.confirmPassword && <small className="p-error mb-2">{errors.confirmPassword}</small>}
                        </div>

                        <Button 
                            type="submit"
                            label="Sign Up"
                            className="w-full mt-6"
                            size="large"
                            loading={loading}
                            style={{
                                background: '#4ea87e',
                                border: 'none',
                                boxShadow: 'none'
                            }}
                        />
                    </form>
            </div>
        </div>
    );
};

export default Signup;
