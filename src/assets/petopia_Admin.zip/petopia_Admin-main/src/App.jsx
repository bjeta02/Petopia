import React from 'react';
import { BrowserRouter as Router, Route, Routes, RouterProvider } from 'react-router-dom';
import SidebarLayout from './components/SidebarLayout';
import Dashboard from './pages/Dashboard';
import Appointments  from './pages/Appointment';
import Login from './pages/Login'; // A page without the sidebar
import Signup from './pages/Signup';
import Services from './pages/ManageServices';


const App = () => {
    return (
        <Router>
            <Routes>
                {/* Pages with Sidebar */}
                <Route path="/" element={<SidebarLayout />}>
                    <Route path="dashboard" element={<Dashboard />} />
                    <Route path="appointments" element={<Appointments />} />
                    <Route path="services" element={<Services />} />
                </Route>

                {/* Pages without Sidebar */}
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
            </Routes>
        </Router>
    );
};

export default App;
