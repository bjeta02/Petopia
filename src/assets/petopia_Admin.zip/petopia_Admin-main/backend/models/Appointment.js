const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema({
  pet_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Pet', required: true },
  owner_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Owner', required: true },
  clinic_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Clinic', required: true },
  veterinarian_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Staff', required: true },
  date: { type: Date, required: true },
  status: { type: String, enum: ['Pending', 'Scheduled', 'Cancelled'], default: 'Pending' },
  notes: { type: String, maxlength: 500 },
}, { timestamps: true });

// Indexing for performance optimization
appointmentSchema.index({ owner_id: 1, pet_id: 1, date: 1 });

const Appointment = mongoose.model('Appointment', appointmentSchema);
module.exports = Appointment;
