const mongoose = require('mongoose');

const petSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, required: true },
  breed: { type: String },
  age: { type: String },
  gender: { type: String, enum: ['Male', 'Female'], required: true },
  status: { type: String, default: 'Active' },
  owner_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Owner', required: true },
  
});

// Prevent model overwrite
module.exports = mongoose.models.Pet || mongoose.model('Pet', petSchema);