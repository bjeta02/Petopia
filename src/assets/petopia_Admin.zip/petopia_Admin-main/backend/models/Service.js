const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
    clinic_id: {type: mongoose.Schema.Types.ObjectId, ref: 'Clinic', required: true},
    name: { type: String, required: true },
    description: { type: String, required: true },
})