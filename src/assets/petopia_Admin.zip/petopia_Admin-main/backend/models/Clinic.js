const mongoose = require('mongoose');

const staffSchema = new mongoose.Schema({
  name: { type: String, required: true },
  address: { type: String, required: true},
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  description: { type: String, },
  status: { type: String, enum: ['Pending', 'Confirmed', 'Completed', 'Cancelled'], required: true},
  days: [{ type: String }], // Example: ["Monday", "Wednesday", "Friday"]
  open_time: { type: String }, // Example: "08:00 AM"    
  close_time: { type: String } // Example: "05:00 PM"
});

module.exports = mongoose.model('Clinic', staffSchema);
