const mongoose = require('mongoose');

const ownerSchema = new mongoose.Schema({
  first_name: { type: String, required: true },
  last_name: { type: String, required: true },
  email: { type: String, required: true},
  phone: { type: String, required: true },
  address: { type: String },
  password: { type: String, required: true},  
});

// Prevent model overwrite
module.exports = mongoose.models.Owner || mongoose.model('Owner', ownerSchema);
