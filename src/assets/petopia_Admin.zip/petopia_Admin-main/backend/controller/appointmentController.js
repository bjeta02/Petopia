const Appointment = require('../models/Appointment');

const getAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate("owner_id", "first_name last_name") // Fetch owner's full name
      .populate("pet_id", "name type breed") // Fetch pet details
      .populate("veterinarian_id", "name"); // Fetch veterinarian's name

    console.log("Fetched Appointments:", appointments); // Debugging line

    // Manually format owner's full name
    const formattedAppointments = appointments.map((appointment) => ({
      ...appointment._doc,
      owner_full_name: appointment.owner_id
        ? `${appointment.owner_id.first_name} ${appointment.owner_id.last_name}`
        : "Unknown Owner",
    }));

    res.status(200).json(formattedAppointments);
  } catch (error) {
    console.error("Error fetching appointments:", error);
    res.status(500).json({ message: "Server error", error });
  }
};

module.exports = { getAppointments };
