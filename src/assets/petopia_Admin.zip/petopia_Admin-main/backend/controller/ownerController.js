const Owner = require('../models/Owner');

exports.getOwners = async (req, res) => {
  try {
    const owners = await Owner.find();
    res.json(owners);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createOwner = async (req, res) => {
  try {
    const { first_name, last_name, contact_info, address, pets } = req.body;
    const newOwner = new Owner({ first_name, last_name, contact_info, address, pets });
    await newOwner.save();
    res.status(201).json(newOwner);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateOwner = async (req, res) => {
  try {
    const owner = await Owner.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!owner) return res.status(404).json({ message: 'Owner not found' });
    res.json(owner);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteOwner = async (req, res) => {
  try {
    const owner = await Owner.findByIdAndDelete(req.params.id);
    if (!owner) return res.status(404).json({ message: 'Owner not found' });
    res.json({ message: 'Owner deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
