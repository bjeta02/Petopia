const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment'); // Ensure this matches your schema

// Get all appointments
router.get('/', async (req, res) => {
    try {
        const appointments = await Appointment.find()
            .populate("owner_id", "first_name last_name") // Fetch owner's full name
            .populate("pet_id", "name type breed") // Fetch pet details
            .populate("veterinarian_id", "name"); // Fetch veterinarian's name

        res.json(appointments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Create an appointment
router.post('/', async (req, res) => {
    const appointment = new Appointment(req.body);
    try {
        const newAppointment = await appointment.save();
        res.status(201).json(newAppointment);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Update appointment
router.put('/:id', async (req, res) => {
    try {
        const updatedAppointment = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedAppointment);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete (or mark as rejected)
router.delete('/:id', async (req, res) => {
    try {
        await Appointment.findByIdAndDelete(req.params.id);
        res.json({ message: 'Appointment deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
