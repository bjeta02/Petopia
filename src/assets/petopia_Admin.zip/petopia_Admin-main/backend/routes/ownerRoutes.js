const express = require('express');
const router = express.Router();
const { getOwners, createOwner, updateOwner, deleteOwner } = require('../controller/ownerController');

router.get('/', getOwners);
router.post('/', createOwner);
router.put('/:id', updateOwner);
router.delete('/:id', deleteOwner);

module.exports = router;
