const express = require('express');
const router = express.Router();
const { getPets, createPet, updatePet, deletePet } = require('../controller/petController');

router.get('/', getPets);
router.post('/', createPet);
router.put('/:id', updatePet);
router.delete('/:id', deletePet);

module.exports = router;
